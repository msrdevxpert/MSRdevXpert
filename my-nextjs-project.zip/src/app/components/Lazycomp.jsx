// src/app/components/Lazycomp.jsx
import React from 'react';

const Lazycomp = () => {
  return (
    <div style={{ textAlign: 'center', margin: '2rem 0' }}>
      <h2>This is a lazy-loaded component 🎉</h2>
      <p>It loaded only when needed to improve performance.</p>
    </div>
  );
};

export default Lazycomp;
