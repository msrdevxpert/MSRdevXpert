(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1590e970._.js",
  "static/chunks/node_modules_aos_dist_aos_9414069c.css"
],
    source: "dynamic"
});
