(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_antd_es_form_b375ee5e._.js",
  "static/chunks/node_modules_antd_es_date-picker_c690eba6._.js",
  "static/chunks/node_modules_antd_es_modal_35890d6d._.js",
  "static/chunks/node_modules_antd_es_color-picker_00510309._.js",
  "static/chunks/node_modules_antd_es_input_fcb5191f._.js",
  "static/chunks/node_modules_antd_es_table_b22d4ca9._.js",
  "static/chunks/node_modules_antd_es_d10a60ab._.js",
  "static/chunks/7c130_@ant-design_icons_es_b8f62273._.js",
  "static/chunks/node_modules_rc-picker_es_cb69a229._.js",
  "static/chunks/node_modules_rc-field-form_es_1df1108d._.js",
  "static/chunks/node_modules_rc-select_es_a627b9e8._.js",
  "static/chunks/node_modules_rc-menu_es_dea1b9c2._.js",
  "static/chunks/node_modules_rc-tabs_es_eb5572a2._.js",
  "static/chunks/node_modules_@ant-design_react-slick_es_4cfff4cf._.js",
  "static/chunks/node_modules_rc-cascader_es_3a81b699._.js",
  "static/chunks/node_modules_rc-tree_es_9f3aaed9._.js",
  "static/chunks/node_modules_rc-slider_es_abdb2d93._.js",
  "static/chunks/node_modules_rc-table_es_23647edc._.js",
  "static/chunks/node_modules_rc-tree-select_es_a0fd8e81._.js",
  "static/chunks/node_modules_@mui_material_esm_daec36ec._.js",
  "static/chunks/node_modules_@mui_system_esm_9208743a._.js",
  "static/chunks/node_modules_@rc-component_81cca479._.js",
  "static/chunks/node_modules_e29ff2b7._.js"
],
    source: "dynamic"
});
