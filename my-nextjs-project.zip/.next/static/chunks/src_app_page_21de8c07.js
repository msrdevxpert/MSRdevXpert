(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_components_Lazycomp_jsx_171c4063._.js",
  "static/chunks/_78652998._.js"
],
    source: "dynamic"
});
