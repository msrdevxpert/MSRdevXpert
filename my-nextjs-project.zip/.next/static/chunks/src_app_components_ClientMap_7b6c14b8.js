(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_leaflet_dist_leaflet-src_e7e140e9.js",
  "static/chunks/src_app_components_ClientMap_6f136b4d.js",
  "static/chunks/node_modules_leaflet_dist_leaflet_88e19fd3.css"
],
    source: "dynamic"
});
