(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_components_Lazycomp_jsx_1c845599._.js",
  "static/chunks/_ab83f5a6._.js",
  "static/chunks/node_modules_aos_dist_aos_9414069c.css"
],
    source: "dynamic"
});
