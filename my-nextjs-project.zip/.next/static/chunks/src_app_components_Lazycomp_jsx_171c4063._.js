(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/components/Lazycomp.jsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_app_components_Lazycomp_jsx_8b2559fe._.js",
  "static/chunks/src_app_components_Lazycomp_jsx_f1e8d82d._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/components/Lazycomp.jsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);