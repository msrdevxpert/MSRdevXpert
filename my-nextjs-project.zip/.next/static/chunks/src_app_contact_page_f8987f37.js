(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_components_ClientMap_4d03b09a.js",
  "static/chunks/node_modules_efaf633f._.js",
  "static/chunks/src_app_e2c22426._.js"
],
    source: "dynamic"
});
