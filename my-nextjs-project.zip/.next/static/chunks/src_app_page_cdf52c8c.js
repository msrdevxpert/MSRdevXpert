(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_fd984cee._.js",
  "static/chunks/node_modules_aos_dist_aos_9414069c.css"
],
    source: "dynamic"
});
