module.exports = {

"[project]/src/app/components/Lazycomp.jsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_app_components_Lazycomp_jsx_7c76fe92._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/components/Lazycomp.jsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};