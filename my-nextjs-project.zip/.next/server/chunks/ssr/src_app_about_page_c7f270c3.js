module.exports = {

"[project]/src/app/about/page.js [app-rsc] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_app_about_page_1ff2cb40.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/about/page.js [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}}),

};