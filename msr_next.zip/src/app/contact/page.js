'use client';
import React, { useState } from "react";
import { Button, Collapse } from "antd";
import {
  MailOutlined,
  PhoneOutlined,
  EnvironmentOutlined,
} from "@ant-design/icons";
import CollapsePanel from "antd/es/collapse/CollapsePanel";
import dynamic from "next/dynamic";
import emailjs from "emailjs-com"; // Import EmailJS
const ClientMap = dynamic(() => import("../components/ClientMap"), { ssr: false });

const faqData = [
  {
    question: "How do you approach new projects?",
    answer:
      "We begin with a thorough discovery phase to understand your business goals, target audience, and requirements. Then we create a detailed project plan, including timeline and milestones, before moving to design and development phases. Throughout the process, we maintain clear communication and regular updates.",
  },
  {
    question: "What industries do you work with?",
    answer:
      "We work with a diverse range of industries, including healthcare, finance, retail, education, technology, and more. Our adaptable approach allows us to understand the unique challenges and opportunities in each sector and deliver tailored solutions.",
  },
  {
    question: "How long does it typically take to complete a project?",
    answer:
      "Project timelines vary based on scope, complexity, and requirements. A simple website might take 4–6 weeks, while a comprehensive web application could take 3–6 months. During our initial consultation, we’ll provide a more accurate timeline for your specific project.",
  },
  {
    question: "Do you provide ongoing support after project completion?",
    answer:
      "Yes, we offer various maintenance and support plans to ensure your solution continues to perform optimally. Our support services include bug fixes, security updates, performance optimization, and feature enhancements.",
  },
  {
    question: "What is your pricing structure?",
    answer:
      "We offer flexible pricing models, including fixed-price quotes for well-defined projects and time-and-materials billing for more complex or evolving projects.",
  },
];

const Contact = () => {
  const items = faqData.map((item, index) => ({
    key: index.toString(),
    label: item.question,
    children: <p>{item.answer}</p>,
  }));

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

    // Handle form input change
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData({ ...formData, [name]: value });
    };
  
    // Handle form submit
    const handleSubmit = (e) => {
      e.preventDefault();
  
      const { name, email, message } = formData;
  
      if (!name || !email || !message) {
        alert("Please fill in all fields");
        return;
      }
  
      // EmailJS send function
      emailjs
        .send(
          "service_n1l686u", // Replace with your service ID
          "template_1bvmcyf", // Replace with your template ID
          {
            from_name: name,
            from_email: email,
            message: message,
          },
          "oFVhdo4NTEN07FhP_" // Replace with your user ID from EmailJS dashboard
        )
        .then(
          (response) => {
            console.log("Email sent successfully:", response);
            alert("Message sent successfully!");
            setFormData({ name: "", email: "", message: "" }); // Reset form
          },
          (error) => {
            console.log("Error sending email:", error);
            alert("Failed to send message. Please try again later.");
          }
        );
    };

  return (
    <section className="contact-section">
      <div className="orange-ball"></div>
      <div className="contact-container">
        <h1>
          <span>Let's</span> Get In Touch
        </h1>
        <p className="section-subtitle">
          We’d love to hear from you. Drop us a message below!
        </p>
        <div className="contact-info">
        <form className="contact-form" onSubmit={handleSubmit}>
            <h3 className="msgTitle">
              <span>Send</span> us a message
            </h3>
            <input
              type="text"
              name="name"
              placeholder="Your Name"
              value={formData.name}
              onChange={handleChange}
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <textarea
              name="message"
              placeholder="Your Message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              required
            ></textarea>
            <Button type="submit" size="large">
              Send Message
            </Button>
          </form>
          <div className="contact-details">
            <h3 className="msgTitle">
              <span>Contact</span> Details
            </h3>
            <p>
              <MailOutlined style={{ marginRight: "8px" }} />
              <strong>Email:</strong> msrdevxpert@gmail.com
            </p>
            <p>
              <PhoneOutlined style={{ marginRight: "8px" }} />
              <strong>Phone:</strong> +91 76672 29002
            </p>
            <p>
              <EnvironmentOutlined style={{ marginRight: "8px" }} />
              <strong>Address:</strong> Ecostation Business Tower, Street Number 9, BP Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091
            </p>

            {/* Embedded Map */}
            <div className="map-container" style={{ marginTop: "20px" }}>
              <ClientMap />
            </div>
          </div>
        </div>

        <div className="faq-wrapper">
  <div className="faq-section">
    <h2 className="faq-title">
      <span>Frequently</span> Asked Questions
    </h2>
    <p className="faq-subtitle">
      Find answers to common questions about our services.
    </p>
    <Collapse accordion className="custom-collapse" items={items} />
  </div>
</div>
      </div>
    </section>
  );
};

export default Contact;
